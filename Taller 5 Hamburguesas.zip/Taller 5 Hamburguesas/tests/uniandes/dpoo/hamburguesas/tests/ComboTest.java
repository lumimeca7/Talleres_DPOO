

package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class ComboTest {

    private Combo combo;
    private ProductoMenu hamburguesa;
    private ProductoMenu papas;

    @BeforeEach
    public void setUp() {
        hamburguesa = new ProductoMenu("Hamburguesa", 10000);
        papas = new ProductoMenu("Papas", 5000);

        ArrayList<ProductoMenu> items = new ArrayList<>();
        items.add(hamburguesa);
        items.add(papas);

        // 10% de descuento -> se paga 90%
        combo = new Combo("Combo 1", 0.9, items);
    }

    @Test
    public void testGetNombre() {
        assertEquals("Combo 1", combo.getNombre(), "El nombre del combo no es correcto");
    }

    @Test
    public void testGetPrecio() {
        // Precio normal: 10000 + 5000 = 15000
        // Con descuento (0.9): 15000 * 0.9 = 13500
        assertEquals(13500, combo.getPrecio(), "El precio del combo no es correcto");
    }

    @Test
    public void testGenerarTextoFactura() {
        String texto = combo.generarTextoFactura();

        assertNotNull(texto, "El texto no debería ser null");
        assertTrue(texto.contains("Combo Combo 1"), "Debe contener el nombre del combo");
        assertTrue(texto.contains("Descuento"), "Debe contener el descuento");
        assertTrue(texto.contains("13500"), "Debe contener el precio final");
    }

    @Test
    public void testComboSinDescuento() {
        ArrayList<ProductoMenu> items = new ArrayList<>();
        items.add(hamburguesa);

        Combo comboSinDescuento = new Combo("Combo 2", 1.0, items);

        assertEquals(10000, comboSinDescuento.getPrecio(),
                "Sin descuento el precio debe ser igual al producto base");
    }
}