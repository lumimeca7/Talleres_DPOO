package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class ProductoMenuTest {

    private ProductoMenu producto;

    @BeforeEach
    public void setUp() {
        producto = new ProductoMenu("Hamburguesa Sencilla", 10000);
    }

    @Test
    public void testGetNombre() {
        assertEquals("Hamburguesa Sencilla", producto.getNombre(), "El nombre del producto no es correcto");
    }

    @Test
    public void testGetPrecio() {
        assertEquals(10000, producto.getPrecio(), "El precio base no es correcto");
    }

    @Test
    public void testGenerarTextoFactura() {
        String esperado = "Hamburguesa Sencilla\n" +
                          "            10000\n";

        assertEquals(esperado, producto.generarTextoFactura(), "El texto de la factura no es correcto");
    }

    @Test
    public void testProductoConOtroValor() {
        ProductoMenu producto2 = new ProductoMenu("Papas Medianas", 5000);

        assertEquals("Papas Medianas", producto2.getNombre());
        assertEquals(5000, producto2.getPrecio());

        String esperado = "Papas Medianas\n" +
                          "            5000\n";

        assertEquals(esperado, producto2.generarTextoFactura());
    }
}