package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.ProductoAjustado;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class ProductoAjustadoTest {

    private ProductoAjustado producto;
    private ProductoMenu base;

    @BeforeEach
    public void setUp() {
        base = new ProductoMenu("Hamburguesa", 10000);
        producto = new ProductoAjustado(base);
    }

    @Test
    public void testGetNombre() {
        assertEquals("Hamburguesa", producto.getNombre(), "El nombre debe ser el del producto base");
    }

    @Test
    public void testPrecioSinAgregados() {
                assertEquals(10000, producto.getPrecio(),
                "Sin agregados ni eliminados, el precio debe ser igual al del producto base");
    }

    @Test
    public void testGenerarTextoFacturaSinCambios() {
        String texto = producto.generarTextoFactura();
               assertNotNull(texto, "La factura no debería ser null");
        assertFalse(texto.isEmpty(), "La factura no debería estar vacía");
        assertTrue(texto.contains("Hamburguesa"),
                "La factura debería contener el nombre del producto base");
        assertTrue(texto.contains("10000"),
                "La factura debería contener el precio del producto base");
    }

}