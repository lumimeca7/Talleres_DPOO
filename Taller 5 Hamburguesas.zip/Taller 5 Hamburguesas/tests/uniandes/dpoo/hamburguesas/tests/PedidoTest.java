package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class PedidoTest {

    private Pedido pedido;
    private ProductoMenu hamburguesa;
    private ProductoMenu papas;

    @BeforeEach
    public void setUp() {
        pedido = new Pedido("Luis", "Calle 123");
        hamburguesa = new ProductoMenu("Hamburguesa", 10000);
        papas = new ProductoMenu("Papas", 5000);
    }

    @Test
    public void testGetNombreCliente() {
        assertEquals("Luis", pedido.getNombreCliente(), "El nombre del cliente no es correcto");
    }

    @Test
    public void testAgregarProductoYPrecioTotal() {
        pedido.agregarProducto(hamburguesa);
        pedido.agregarProducto(papas);

        int precioNetoEsperado = 15000;
        int ivaEsperado = (int) (precioNetoEsperado * 0.19);
        int totalEsperado = precioNetoEsperado + ivaEsperado;

        assertEquals(totalEsperado, pedido.getPrecioTotalPedido(),
                "El precio total del pedido no coincide con neto + IVA");
    }

    @Test
    public void testGenerarTextoFactura() {
        pedido.agregarProducto(hamburguesa);
        pedido.agregarProducto(papas);

        String factura = pedido.generarTextoFactura();

        assertNotNull(factura, "La factura no debería ser null");
        assertTrue(factura.contains("Cliente: Luis"), "La factura debe contener el nombre del cliente");
        assertTrue(factura.contains("Dirección: Calle 123"), "La factura debe contener la dirección");
        assertTrue(factura.contains("Hamburguesa"), "La factura debe contener el producto hamburguesa");
        assertTrue(factura.contains("Papas"), "La factura debe contener el producto papas");
        assertTrue(factura.contains("Precio Neto:  15000"), "La factura debe contener el precio neto correcto");
        assertTrue(factura.contains("IVA:          2850"), "La factura debe contener el IVA correcto");
        assertTrue(factura.contains("Precio Total: 17850"), "La factura debe contener el total correcto");
    }

    @Test
    public void testGuardarFactura() throws Exception {
        pedido.agregarProducto(hamburguesa);

        File archivo = File.createTempFile("factura_pedido_", ".txt");
        archivo.deleteOnExit();

        pedido.guardarFactura(archivo);

        String contenido = Files.readString(archivo.toPath(), StandardCharsets.UTF_8);
        assertEquals(pedido.generarTextoFactura(), contenido,
                "El contenido del archivo debe ser igual al texto de la factura generada");
    }

    @Test
    public void testGetIdPedidoIncrementa() {
        Pedido pedido2 = new Pedido("Ana", "Carrera 45");
        assertTrue(pedido2.getIdPedido() > pedido.getIdPedido(),
                "El identificador de los pedidos debe incrementarse al crear nuevos pedidos");
    }

    @Test
    public void testGuardarFacturaLanzaExcepcion() {
        pedido.agregarProducto(hamburguesa);

        File archivoInvalido = new File(".");

        boolean lanzo = false;
        try {
            pedido.guardarFactura(archivoInvalido);
        } catch (FileNotFoundException e) {
            lanzo = true;
        }

        assertTrue(lanzo, "Debe lanzarse FileNotFoundException cuando no se puede crear el archivo");
    }
}
