package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.excepciones.IngredienteRepetidoException;
import uniandes.dpoo.hamburguesas.excepciones.NoHayPedidoEnCursoException;
import uniandes.dpoo.hamburguesas.excepciones.ProductoFaltanteException;
import uniandes.dpoo.hamburguesas.excepciones.ProductoRepetidoException;
import uniandes.dpoo.hamburguesas.excepciones.YaHayUnPedidoEnCursoException;
import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
import uniandes.dpoo.hamburguesas.mundo.Restaurante;

public class RestauranteTest {

    private Restaurante restaurante;

    @BeforeEach
    public void setUp() {
        restaurante = new Restaurante();
    }

    @Test
    public void testIniciarPedido() throws Exception {
        restaurante.iniciarPedido("Luis", "Calle 123");
        Pedido pedido = restaurante.getPedidoEnCurso();

        assertNotNull(pedido, "Debe existir un pedido en curso");
        assertEquals("Luis", pedido.getNombreCliente(), "El nombre del cliente no es correcto");
    }

    @Test
    public void testIniciarPedidoYaExiste() throws Exception {
        restaurante.iniciarPedido("Luis", "Calle 123");

        assertThrows(YaHayUnPedidoEnCursoException.class, () -> {
            restaurante.iniciarPedido("Ana", "Otra direccion");
        }, "Debe lanzar excepción si ya existe un pedido en curso");
    }

    @Test
    public void testCerrarPedidoSinPedido() {
        assertThrows(NoHayPedidoEnCursoException.class, () -> {
            restaurante.cerrarYGuardarPedido();
        }, "Debe lanzar excepción si no hay pedido en curso");
    }

    @Test
    public void testCerrarPedidoCorrectamente() throws Exception {
        new File("./facturas/").mkdirs();

        restaurante.iniciarPedido("Luis", "Calle 123");
        Pedido pedido = restaurante.getPedidoEnCurso();
        pedido.agregarProducto(new ProductoMenu("Hamburguesa", 10000));

        restaurante.cerrarYGuardarPedido();

        assertNull(restaurante.getPedidoEnCurso(), "Después de cerrar el pedido no debe haber pedido en curso");
        assertTrue(restaurante.getPedidos().size() >= 1, "El pedido cerrado debe quedar registrado");
    }

    @Test
    public void testCargarInformacionRestaurante() throws Exception {
        File archivoIngredientes = File.createTempFile("ingredientes", ".txt");
        PrintWriter writerIng = new PrintWriter(archivoIngredientes);
        writerIng.println("Queso;2000");
        writerIng.println("Tocineta;3000");
        writerIng.close();

        File archivoMenu = File.createTempFile("menu", ".txt");
        PrintWriter writerMenu = new PrintWriter(archivoMenu);
        writerMenu.println("Hamburguesa;10000");
        writerMenu.println("Papas;5000");
        writerMenu.close();

        File archivoCombos = File.createTempFile("combos", ".txt");
        PrintWriter writerCombo = new PrintWriter(archivoCombos);
        writerCombo.println("Combo1;10%;Hamburguesa;Papas");
        writerCombo.close();

        restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);

        assertEquals(2, restaurante.getIngredientes().size(), "Debe cargar los ingredientes correctamente");
        assertEquals(2, restaurante.getMenuBase().size(), "Debe cargar el menú base correctamente");
        assertEquals(1, restaurante.getMenuCombos().size(), "Debe cargar los combos correctamente");
    }

    @Test
    public void testIngredienteRepetido() throws Exception {
        File archivoIngredientes = File.createTempFile("ingredientes", ".txt");
        PrintWriter writerIng = new PrintWriter(archivoIngredientes);
        writerIng.println("Queso;2000");
        writerIng.println("Queso;3000");
        writerIng.close();

        File archivoMenu = File.createTempFile("menu", ".txt");
        PrintWriter writerMenu = new PrintWriter(archivoMenu);
        writerMenu.println("Hamburguesa;10000");
        writerMenu.close();

        File archivoCombos = File.createTempFile("combos", ".txt");
        PrintWriter writerCombo = new PrintWriter(archivoCombos);
        writerCombo.close();

        assertThrows(IngredienteRepetidoException.class, () -> {
            restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
        }, "Debe lanzar excepción cuando hay ingredientes repetidos");
    }

    @Test
    public void testProductoRepetido() throws Exception {
        File archivoIngredientes = File.createTempFile("ingredientes", ".txt");
        PrintWriter writerIng = new PrintWriter(archivoIngredientes);
        writerIng.println("Queso;2000");
        writerIng.close();

        File archivoMenu = File.createTempFile("menu", ".txt");
        PrintWriter writerMenu = new PrintWriter(archivoMenu);
        writerMenu.println("Hamburguesa;10000");
        writerMenu.println("Hamburguesa;12000");
        writerMenu.close();

        File archivoCombos = File.createTempFile("combos", ".txt");
        PrintWriter writerCombo = new PrintWriter(archivoCombos);
        writerCombo.close();

        assertThrows(ProductoRepetidoException.class, () -> {
            restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
        }, "Debe lanzar excepción cuando hay productos repetidos en el menú");
    }

    @Test
    public void testProductoFaltanteEnCombo() throws Exception {
        File archivoIngredientes = File.createTempFile("ingredientes", ".txt");
        PrintWriter writerIng = new PrintWriter(archivoIngredientes);
        writerIng.println("Queso;2000");
        writerIng.close();

        File archivoMenu = File.createTempFile("menu", ".txt");
        PrintWriter writerMenu = new PrintWriter(archivoMenu);
        writerMenu.println("Hamburguesa;10000");
        writerMenu.close();

        File archivoCombos = File.createTempFile("combos", ".txt");
        PrintWriter writerCombo = new PrintWriter(archivoCombos);
        writerCombo.println("Combo1;10%;Papas");
        writerCombo.close();

        assertThrows(ProductoFaltanteException.class, () -> {
            restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
        }, "Debe lanzar excepción cuando un combo referencia un producto inexistente");
    }

    @Test
    public void testGettersColecciones() {
        ArrayList<ProductoMenu> menuBase = restaurante.getMenuBase();

        assertNotNull(menuBase, "El menú base no debe ser null");
        assertNotNull(restaurante.getMenuCombos(), "El menú de combos no debe ser null");
        assertNotNull(restaurante.getIngredientes(), "La lista de ingredientes no debe ser null");
        assertNotNull(restaurante.getPedidos(), "La lista de pedidos no debe ser null");
    }
    
    @Test
    public void testComboRepetido() throws Exception {
        File archivoIngredientes = File.createTempFile("ingredientes", ".txt");
        PrintWriter writerIng = new PrintWriter(archivoIngredientes);
        writerIng.println("Queso;2000");
        writerIng.close();

        File archivoMenu = File.createTempFile("menu", ".txt");
        PrintWriter writerMenu = new PrintWriter(archivoMenu);
        writerMenu.println("Hamburguesa;10000");
        writerMenu.println("Papas;5000");
        writerMenu.close();

        File archivoCombos = File.createTempFile("combos", ".txt");
        PrintWriter writerCombo = new PrintWriter(archivoCombos);
        writerCombo.println("Combo1;10%;Hamburguesa;Papas");
        writerCombo.println("Combo1;15%;Hamburguesa");
        writerCombo.close();

        assertThrows(ProductoRepetidoException.class, () -> {
            restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
        }, "Debe lanzar excepción cuando hay combos repetidos");
    }
}
